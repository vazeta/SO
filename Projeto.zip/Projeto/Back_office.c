// CODED BY:
// André Teixeira - 2022231134
// João Vaz - 2022231087

#include "Back_office.h"
#include "SharedFunc.h"
#include "Struct.h"
#include <signal.h>
#define PIPE_NAME2 "/tmp/BACK_OFFICE_PIPE"
#define BUFFER_SIZE 1024


int main(){
    signal(SIGINT, sigint_handler);
    create_back_office();
}

void create_back_office(){
    if(pthread_create(&read_from_msg_queue,NULL,read_msg,NULL)==-1){
            perror("Error creating threads request\n");
        }
    while(1){
        char String_enviar[BUFFER_SIZE];
        fgets(String_enviar,BUFFER_SIZE,stdin);
        String_enviar[strcspn(String_enviar, "\n")]='\0';
        if(strcmp(String_enviar, "1#data_stats")==0 || strcmp(String_enviar, "1#reset")==0){
            write_to_back_pipe(String_enviar);
        }else{
            printf("Comando invalido\n");
        }
    }
    if(pthread_join(read_from_msg_queue,NULL) != 0){
            perror("Error in join function");
    }
}


void write_to_back_pipe(char *String_enviar){
    if((pipe_back = open(PIPE_NAME2, O_RDWR)) < 0) {
            perror("Cannot open pipe for reading: ");
            exit(0);
    }
    if(write(pipe_back, String_enviar, strlen(String_enviar))==-1){
            perror("Error writing to user pipe\n");
            exit(0);
    }
    return;
}

void *read_msg(){
    msg stats2;
    while(1) {
        if(msgrcv(msg_queue_id,&stats2, sizeof(msg), 5, 0) == -1) {
            perror("Error receiving from msg queue\n");
            exit(-1);
        }
        printf("%s\n", stats2.alerta);
    }
}

void sigint_handler(int signum) {
    (void)signum;
    close_back_office();
}

void close_back_office(){
    close(pipe_back);
    pthread_cancel(read_from_msg_queue);
    pthread_join(read_from_msg_queue, NULL);

    msgctl(msg_queue_id, IPC_RMID, NULL);
    exit(0);
}