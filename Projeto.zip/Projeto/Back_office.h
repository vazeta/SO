// CODED BY:
// André Teixeira - 2022231134
// João Vaz - 2022231087

#ifndef BACK_OFFICE_H
#define MBACK_OFFICE_H

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <sys/msg.h>
#include <fcntl.h>
#include <sys/types.h>
#include <time.h>
#include <signal.h>
#include <semaphore.h>
#include <ctype.h>
#include <errno.h>
#include <sys/select.h>
#include <assert.h>
#include <sys/mman.h>
#include <stdbool.h>
extern int msg_queue_id;
int msg_queue_id;
pthread_t read_from_msg_queue;

int pipe_back = 0;

void create_back_office();
void write_to_back_pipe(char command[]);
void *read_msg();
void sigint_handler(int signum);
void close_back_office();

#endif