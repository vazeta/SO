// CODED BY:
// André Teixeira - 2022231134
// João Vaz - 2022231087

#include "Mobile_user.h"
#include "Struct.h"
#include "SharedFunc.h"

#define PIPE_NAME "/tmp/USER_PIPE"
int count_requests;
pthread_mutex_t mutex_requests= PTHREAD_MUTEX_INITIALIZER;
char command[100];
pthread_t video_thread,social_thread,musical_thread, read_from_msg_queue;
extern int msg_queue_id;
int msg_queue_id;
msg alerta_recebido;
int flag = 1;
int main(int argc, char *argv[]){
    signal(SIGINT, sigint_handler);
    if(argc != 7){
        perror("INCORRET NUMBER OF ARGUMENTS\n");
        exit(-1);
    }
    USER_request user;
    if(argument_check(argv)){
        user.initial_plafon = atoi(argv[1]);
        user.AUTH_requestNum = atoi(argv[2]);
        user.VIDEO_period = atoi(argv[3]);
        user.MUSIC_period = atoi(argv[4]);
        user.SOCIAL_period = atoi(argv[5]);
        user.DATA_request = atoi(argv[6]);
        create_mobile_user(user);
    }
}

int is_integer(const char *str) {
    for (int i = 0; str[i] != '\0'; i++) {
        if (!isdigit(str[i])) {
            return 0;
        }
    }
    return 1; 
}

int argument_check(char *argv[]) {
    for (int i = 1; i <= 6; ++i) {
        if (!is_integer(argv[i])) {
            perror("ERROR! INVALID ARGUMENT(S)\n");
            return 0; 
        }
        int arg = atoi(argv[i]);
        if (arg <= 0) {
            perror("ERROR! INVALID ARGUMENT(S)\n");
            return 0; 
        }
    }
    return 1; 
}

       

void create_mobile_user(USER_request user){
    pid_t pid = fork();
    if (pid == 0) {
        
        snprintf(command,sizeof(command),"%d#%d\n",getpid(),user.initial_plafon);
        write_to_user_pipe(command);
        count_requests = 3;
        USER_request *arg = &user;
        alerta_recebido.mtype = pid;
        if(pthread_create(&video_thread,NULL,video_request, (void *)arg)==-1){
            perror("Error creating threads request\n");
        }
        if(pthread_create(&social_thread,NULL,social_request,(void *)arg)==-1){
            perror("Error creating threads request\n");
        }
        if(pthread_create(&musical_thread,NULL,musical_request,(void *)arg)==-1){
            perror("Error creating threads request\n");
        }
        if(pthread_create(&read_from_msg_queue,NULL,read_user_msg,NULL)==-1){
            perror("Error creating threads request\n");
        }
        if(pthread_join(video_thread,NULL) != 0){
            perror("Error in join function");
        }
        if(pthread_join(musical_thread,NULL) != 0){
            perror("Error in join function");
        }
        if(pthread_join(social_thread,NULL) != 0){
            perror("Error in join function");
        }
        if(pthread_join(read_from_msg_queue,NULL) != 0){
            perror("Error in join function");
        }
        
        exit(0);

    } else if (pid < 0) {
        perror("ERROR CREATING MOBILE USER\n");
        exit(-1);
    }
    wait(NULL);
    exit(0);
}


void write_to_user_pipe(char *command){
    if((pipe_user = open(PIPE_NAME, O_RDWR)) < 0) {
            perror("Cannot open pipe for reading: ");
            exit(0);
    }
    if(write(pipe_user, command, strlen(command))==-1){
            perror("Error writing to user pipe\n");
            exit(0);
    }
    count_requests++;
}

void *video_request(void *arg){
    USER_request *user = (USER_request *)arg;
    while(count_requests <= user->AUTH_requestNum && flag == 1){
        usleep(user->VIDEO_period*1000);
        pthread_mutex_lock(&mutex_requests);
        snprintf(command,sizeof(command)-1,"%d#VIDEO#%d\n",getpid(),user->DATA_request);
        write_to_user_pipe(command);
        pthread_mutex_unlock(&mutex_requests);
    }
    exit(0);
}

void *social_request(void *arg){
    USER_request *user = (USER_request *)arg;
    while(count_requests <= user->AUTH_requestNum && flag == 1){
        usleep(user->SOCIAL_period*1000);
        pthread_mutex_lock(&mutex_requests);
        snprintf(command,sizeof(command),"%d#SOCIAL#%d\n",getpid(),user->DATA_request);
        write_to_user_pipe(command);
        pthread_mutex_unlock(&mutex_requests);
    }
    exit(0); 
}

void *musical_request(void *arg){
    USER_request *user = (USER_request *)arg;
    while(count_requests <= user->AUTH_requestNum && flag == 1){
        usleep(user->MUSIC_period*1000);
        pthread_mutex_lock(&mutex_requests);
        snprintf(command,sizeof(command)-1,"%d#MUSIC#%d\n",getpid(),user->DATA_request);
        write_to_user_pipe(command);
        pthread_mutex_unlock(&mutex_requests);
    }
    exit(0);
}

void *read_user_msg(){
    while(1) {
        if(msgrcv(msg_queue_id, &alerta_recebido, sizeof(msg), getpid(), 0) == -1) {
            perror("Error receiving from msg queue\n");
            exit(-1);
        }
        printf("Acheaved %s percentage plafon\n", alerta_recebido.alerta);
        if(strcmp(alerta_recebido.alerta,"100") == 0){
            flag = 0;
        }
    }
}

void sigint_handler(int signum) {
    (void)signum;
    close_mobile();
}


void close_mobile(){
    pthread_cancel(video_thread);
    pthread_cancel(social_thread);
    pthread_cancel(musical_thread);
    pthread_cancel(read_from_msg_queue);
    pthread_join(video_thread, NULL);
    pthread_join(social_thread, NULL);
    pthread_join(musical_thread, NULL);
    pthread_join(read_from_msg_queue, NULL);
    close(pipe_user);
    msgctl(msg_queue_id, IPC_RMID, NULL);
    pthread_mutex_destroy(&mutex_requests);
    exit(0);   
}