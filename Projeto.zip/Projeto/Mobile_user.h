// CODED BY:
// André Teixeira - 2022231134
// João Vaz - 2022231087

#ifndef MOBILE_USER_H
#define MOBILE_USER_H

#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <sys/msg.h>
#include <fcntl.h>
#include <sys/types.h>
#include <time.h>
#include <signal.h>
#include <semaphore.h>
#include <ctype.h>
#include <errno.h>
#include <sys/select.h>
#include <assert.h>
#include <sys/mman.h>
#include <stdbool.h>
#include "Struct.h"
int pipe_user = 0;


void create_mobile_user(USER_request user);
int argument_check(char *argv[]);
int is_integer(const char *str);
void write_to_user_pipe(char *command);
void *video_request(void *arg);
void *social_request(void *arg);
void *musical_request(void *arg);
void *read_user_msg();
void sigint_handler(int signum);
void close_mobile();


#endif