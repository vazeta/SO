// CODED BY:
// André Teixeira - 2022231134
// João Vaz - 2022231087

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "SharedFunc.h"
#include "Struct.h"
#include "sys/time.h"
#define SIZE_CONFIG 6

FILE *file;
sem_t *log_sem;

void read_confFile(char file_name[], config *config2){
    FILE *file = fopen(file_name, "r");
    if (file == NULL)
    {
        write_to_log_console("ERROR!The file does not exist!\n");
        exit(-1);
    }

    char buffer[30];
    int *buff;
    buff=0;
    int index;
    if (fscanf(file, "%d", &config2->MOBILE_USERS) == 1 &&
        fscanf(file, "%d", &config2->QUEUE_POS) == 1 &&
        fscanf(file, "%d", &config2->AUTH_SERVERS_MAX) == 1 &&
        fscanf(file, "%d", &config2->AUTH_PROC_TIME) == 1 &&
        fscanf(file, "%d", &config2->MAX_VIDEO_WAIT) == 1 &&
        fscanf(file, "%d", &config2->MAX_OTHER_WAIT) == 1)
    {
        index = 6;
    }
    if (fscanf(file, "%d", buff) == 1 || fscanf(file, "%s", buffer) == 1)
    {
        index++;
    }
    if ((config2->MOBILE_USERS < 0 && config2->QUEUE_POS < 0))
    {
        write_to_log_console("ERROR!The value of QUEUE_POS or MOBILE_USERS must be greater than or equal to 0.\n");
        fclose(file);
        exit(-1);
    }
    else if ((config2->AUTH_SERVERS_MAX && config2->AUTH_PROC_TIME && config2->MAX_VIDEO_WAIT && config2->MAX_OTHER_WAIT) < 1)
    {
        write_to_log_console("ERROR! One of the values ​​does not comply with what was stipulated!\n");
        fclose(file);
        exit(-1);
    }

    if (index != SIZE_CONFIG)
    {
        write_to_log_console("ERRO!The file does not have exactly 6 lines or does not contain only integers.\n");
        fclose(file);
        exit(-1);
    }
    fclose(file);
}


void open_log(){
    char file_name[] = "log.txt";
    file = fopen(file_name, "w");
    if (file == NULL) {
        fprintf(stderr, "Failed to open the file %s\n", file_name);
        return;
    }
    sem_unlink("log_sem");
    if((log_sem=sem_open("log_sem", O_CREAT | O_EXCL, 0700, 1)) == SEM_FAILED){
        write_to_log_console("Error creating log file semaphore\n");
        exit(-1);
    }
    
}

//semaforo e estar sempre a abrir
void write_to_log_console(char *text){
    sem_wait(log_sem);
    time_t rawtime;
    struct tm *info;
    char buffer[80];

    time(&rawtime);
    info = localtime(&rawtime);
    strftime(buffer, sizeof(buffer), "%H:%M:%S", info);
    if (file == NULL)
    {
        fprintf(stderr, "Failed to open the file %s\n", "log.txt");
        return;
    }
    printf("%s %s", buffer, text);
    fprintf(file, "%s %s", buffer, text);
    fflush(file);
    sem_post(log_sem);
}


long long getTime() {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (long long)tv.tv_sec * 1000LL + (long long)tv.tv_usec / 1000LL;
}