// CODED BY:
// André Teixeira - 2022231134
// João Vaz - 2022231087

#ifndef SHAREDFUNC_H
#define SHAREDFUNC_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <wait.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <semaphore.h> 
#include <time.h>
#include <pthread.h>
#include <sys/wait.h>
#include "Struct.h"
#include "sys/time.h"



void write_to_log_console(char *text);
void read_confFile(char file_name[], config *config2);
long long getTime();
void open_log();




#endif