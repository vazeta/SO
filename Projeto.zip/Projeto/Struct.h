// CODED BY:
// André Teixeira - 2022231134
// João Vaz - 2022231087

#ifndef STRUCT_H
#define STRUCT_H
#define BUFFER_SIZE2 1024
#include <stddef.h>
#include <pthread.h>

typedef struct config {
    int MOBILE_USERS;
    int QUEUE_POS;
    int AUTH_SERVERS_MAX;
    int AUTH_PROC_TIME;
    int MAX_VIDEO_WAIT;
    int MAX_OTHER_WAIT;
} config;


typedef struct USER_TO_SHM{
    int USER_ID;
    int USER_CURRENT_PLAFON;
    int USER_INITIAL_PLAFON;
    int flag;
}USER_TO_SHM;

typedef struct USER_request {
    int initial_plafon;
    int AUTH_requestNum;
    int VIDEO_period;
    int MUSIC_period;
    int SOCIAL_period;
    int DATA_request;
} USER_request;

typedef struct stats {
    int TOTAL_DATA;
    int AUTH_REQUEST_NUM;
}stats;

typedef struct SHARED_MEM {
    USER_TO_SHM *USERS_INFO;
    stats stats[3];
    pthread_mutex_t mutex;
	pthread_cond_t monitor_cond;
} SHARED_MEM;

typedef struct queue{
    char buffer[100];
    time_t entry_time;
    struct queue *next;
}QUEUE;
typedef struct msg{
  long mtype;
  char alerta[BUFFER_SIZE2];                     
} msg;


#endif