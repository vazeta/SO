// CODED BY:
// André Teixeira - 2022231134
// João Vaz - 2022231087

#include "System_manager.h"
#include "SharedFunc.h"
#include "Mobile_user.h"
#include "Back_office.h"

int main(int argc, char *argv[]){
    open_log();
    read_confFile("config_file.txt",&config1);
    if (argc != 2)
    {
        write_to_log_console("INVALID ARGUMENTS");
        exit(-1);
    }
    char file_name[20];
    strcpy(file_name, argv[1]);
    fopen("log.txt", "w");
    write_to_log_console("Welcome to the 5G authorization machine\n");
    create_shared_memory();
    create_msg_queue();
    create_auth_request_manager();
    create_monitor_engine();
}

void create_auth_request_manager()
{
    pid_t pid = fork();
    if (pid < 0)
    {
        write_to_log_console("ERROR! Failed to create process.\n");
        exit(-1);
    }
    else if (pid == 0){   
        write_to_log_console("PROCESS AUTHORIZATION_REQUEST_MANAGER CREATED\n");
        init_sem_queue();
        createNamedPipe();
        create_auth_eng();
        if (pthread_create(&receiver, NULL, receiver_func, NULL) != 0)
        {
            write_to_log_console("Failed to create the first thread.\n");
            exit(-1);
        }
        if (pthread_create(&sender, NULL, sender_func, NULL) != 0)
        {
            write_to_log_console("Failed to create the second thread\n");
            exit(-1);
        }
        pthread_join(receiver, NULL);
        pthread_join(sender, NULL);
        exit(0);
    }

}

void init_sem_queue(){
    sem_unlink("acess_queue");
    if((acess_queue=sem_open("acess_queue", O_CREAT | O_EXCL, 0700, 1)) == SEM_FAILED){
        write_to_log_console("Error creating acess semaphore\n");
        exit(-1);
    }
    sem_unlink("sem_an");
    if((sem_an=sem_open("sem_an", O_CREAT | O_EXCL, 0700, 1)) == SEM_FAILED){
        write_to_log_console("Error creating sender wait semaphore\n");
        exit(-1);
    }
}

void createNamedPipe(){
    unlink(PIPE_NAME);
    unlink(PIPE_NAME2);

    if((mkfifo(PIPE_NAME,O_CREAT|O_EXCL|0777)== -1) && (errno != EEXIST)){
        perror("CANNOT CREATE PIPE: ");
        exit(0);
    }else{
        write_to_log_console("NAMED USER PIPE CREATED\n");
    }
    if((mkfifo(PIPE_NAME2,O_CREAT|O_EXCL|0777)== -1) && (errno != EEXIST)){
        perror("CANNOT CREATE PIPE: ");
        exit(0);   
    }else{
        write_to_log_console("NAMED BACKOFFICE PIPE CREATED\n");
    }
}

//threads
void *receiver_func(){
    write_to_log_console("THREAD RECEIVER CREATED\n");
    if ((pipe_user = open(PIPE_NAME, O_RDWR)) < 0) {
        perror("Cannot open pipe for reading: ");
        exit(0);
    }
    if ((pipe_back = open(PIPE_NAME2, O_RDWR)) < 0) {
        perror("Cannot open pipe for reading: ");
        exit(0);
    }
    
    fd_set readfds;
    int maxfd = (pipe_user > pipe_back) ? pipe_user : pipe_back;
    while (1) {
        FD_ZERO(&readfds);
        FD_SET(pipe_user, &readfds);
        FD_SET(pipe_back, &readfds);

        if (select(maxfd + 1, &readfds, NULL, NULL, NULL) == -1) {
            perror("select");
            exit(EXIT_FAILURE);
        }

        if (FD_ISSET(pipe_user, &readfds)) {
            if (read(pipe_user, buffer, BUFFER_SIZE) > 0) {
                buffer[strcspn(buffer, "\n")]='\0'; //put a \0 in the end of string
            }
            char *result=strstr(buffer,"VIDEO");
            if(result!=NULL){
                if(cont_video < config1.QUEUE_POS){
                    insert_video_queue(&video_queue, buffer);
                    cont_video++;
                }
                else{
                    write_to_log_console("VIDEO QUEUE IS FULL\n");
                }
            }
            else{
                if(cont_others<config1.QUEUE_POS){
                    insert_others_queue(&others_queue, buffer);
                    cont_others++;
                }else{
                    write_to_log_console("OTHERS QUEUE IS FULL\n");
                }
            }
        }

       
        if (FD_ISSET(pipe_back, &readfds)) {
            if (read(pipe_back, buffer2, BUFFER_SIZE) > 0) {
                if(cont_others<config1.QUEUE_POS){
                    buffer2[strcspn(buffer2, "\n")]='\0'; //put a \0 in the end of string
                    insert_others_queue(&others_queue,buffer2);
                    cont_others++;
                }else{
                    write_to_log_console("OTHERS QUEUE IS FULL\n");
                }
            }
        }
    }
    return NULL;
}
void send_to_unnamed_pipe(int n_pipe, char command[]){
    for(int j = 0;j<config1.AUTH_SERVERS_MAX;j++){
            close(fd[j][0]);
    }
    if(write(fd[n_pipe][1],command,BUFFER_SIZE) == -1){
        write_to_log_console("Error writing to unnamed pipe\n");
    }
}

void clear(){
    for(int k = 0; k < config1.AUTH_SERVERS_MAX;k++){
        wait(NULL);
    }
    wait(NULL);
}

void *sender_func(){
    write_to_log_console("THREAD SENDER CREATED\n");
    int num_engines = config1.AUTH_SERVERS_MAX;
    int n_pipe = -1;
    char log_text[BUFFER_SIZE];
    while(1){
        pthread_mutex_lock(&queue_mutex);
        pthread_cond_wait(&queue_condition, &queue_mutex);
        pthread_mutex_unlock(&queue_mutex);
        while(!is_empty(&video_queue)){
            char id_proc[BUFFER_SIZE];
            QUEUE *current=video_queue;
            n_pipe = pick_pipe(num_engines, n_pipe);
            strcpy(id_proc,current->buffer);
            snprintf(log_text, BUFFER_SIZE,"SENDER: VIDEO AUTHORIZATION REQUEST (ID = %d) SENT FOR PROCESSING ON AUTHORIZATION_ENGINE %d\n", atoi(strtok(id_proc, "#")), n_pipe);
            write_to_log_console(log_text);
            if(getTime() - current->entry_time < config1.MAX_VIDEO_WAIT){
                send_to_unnamed_pipe(n_pipe, current->buffer);
            }
            else{
                write_to_log_console("Command VIDEO exeded process time\n");
            }
            if((cont_video == config1.QUEUE_POS || cont_others == config1.QUEUE_POS) && num_engines == config1.AUTH_SERVERS_MAX){
                num_engines++;
                create_extra_engine();
            }
            if((cont_video <= config1.QUEUE_POS/2 || cont_others <= config1.QUEUE_POS/2) && num_engines == config1.AUTH_SERVERS_MAX+1){
                num_engines--;
                kill_extra_engine();
            }
            remove_from_queue(&video_queue);
            cont_video--;
        }if(!is_empty(&others_queue)){
            char id_proc[BUFFER_SIZE];
            QUEUE *current2=others_queue;
            strcpy(id_proc,current2->buffer);
            n_pipe = pick_pipe(num_engines, n_pipe);
            snprintf(log_text, BUFFER_SIZE,"SENDER: OTHER AUTHORIZATION REQUEST (ID = %d) SENT FOR PROCESSING ON AUTHORIZATION_ENGINE %d\n", atoi(strtok(id_proc, "#")), n_pipe);
            write_to_log_console(log_text);
            if(getTime()- current2->entry_time < config1.MAX_OTHER_WAIT){
                send_to_unnamed_pipe(n_pipe, current2->buffer);
            }
            else{
                write_to_log_console("Command OTHERS exeded process time\n");
            }
            remove_from_queue(&others_queue);
            cont_others--;
        }
    }
}


int pick_pipe(int num_engines, int n_pipe){
    for(int i = 0; i < num_engines;i++){
        if(*(ptr+i) == 1 && (i > n_pipe || n_pipe == num_engines-1)){
            sem_wait(sem_an);
            *(ptr+i) = 0;
            sem_post(sem_an);
            return i;
        }
    }
    return -1;
}

void create_monitor_engine(){
    pid_t pid = fork();
    if (pid < 0)
    {
        write_to_log_console("ERROR! Failed to create process.\n");
        exit(-1);
    }
    else if (pid == 0){
        write_to_log_console("PROCESS MONITOR_ENGINE CREATED!\n");
        pthread_t back_office_thread, mobile_user_thread;
        if(pthread_create(&back_office_thread,NULL,send_to_back_ofiice,NULL)==-1){
            write_to_log_console("Error creating threads request\n");
        }
        if(pthread_create(&mobile_user_thread,NULL,alert_user,NULL)==-1){
            write_to_log_console("Error creating threads request\n");
        }
        if(pthread_join(mobile_user_thread,NULL) != 0){
            write_to_log_console("Error in join function");
        }
        if(pthread_join(back_office_thread,NULL) != 0){
            write_to_log_console("Error in join function");
        }
        return;
    }
    else{
        signal(SIGINT, sigint_handler);
        for(int k = 0; k < config1.AUTH_SERVERS_MAX;k++){
            wait(NULL);
        }
        wait(NULL);
    }
}



void insert_video_queue(QUEUE** video_queue,char * buffer){
    sem_wait(acess_queue);
    QUEUE* new_node = (QUEUE*)malloc(sizeof(QUEUE));
    strcpy(new_node->buffer,buffer);
    new_node->entry_time=getTime();
    new_node->next = NULL;
    if (*video_queue == NULL) {
        *video_queue = new_node;
    } else {
        QUEUE* current= *video_queue;
        while (current->next != NULL) {
            current= current->next;
        }
        current->next = new_node;
    }
    pthread_cond_signal(&queue_condition);
    sem_post(acess_queue);
}



void insert_others_queue(QUEUE** others_queue,char * buffer){
    sem_wait(acess_queue);
    QUEUE* new_node = (QUEUE*)malloc(sizeof(QUEUE));
    strcpy(new_node->buffer,buffer);
    new_node->entry_time=getTime();
    new_node->next = NULL;
    if (*others_queue == NULL) {
        *others_queue = new_node;
    } else {
        QUEUE* current= *others_queue;
        while (current->next != NULL) {
            current= current->next;
        }
        current->next = new_node;
    }
    pthread_cond_signal(&queue_condition);
    sem_post(acess_queue);
}

int is_empty(QUEUE** queue){
    if(*queue==NULL){
        return 1;
    }else{
        return 0;
    }
}

void remove_from_queue(QUEUE** queue){
    sem_wait(acess_queue);
    QUEUE *current=*queue;
    if (*queue == NULL || current == NULL) {
        return;
    }
    if (current == *queue) {
        *queue = current->next;
    } else {
        QUEUE* previous = *queue;
        while (previous->next != current) {
            previous = previous->next;
        }
        previous->next = current->next;
    }
    
    free(current);
    sem_post(acess_queue);
}


void create_auth_eng(){
    create_unamed_pipes();
    char command[BUFFER_SIZE];
    for(int i=0;i<config1.AUTH_SERVERS_MAX;i++){
        int pid = fork();
        if(pid < 0){
            write_to_log_console("Error while creating process autorization engine\n");
            exit(-1);
        }
        if(pid == 0){
            snprintf(command,sizeof(command),"AUTHORIZATION_ENGINE %d READY\n",i);
            write_to_log_console(command);
            auth_engine(i);   
            exit(0); 
        }
    }
}

void create_unamed_pipes(){
    for(int p = 0;p <config1.AUTH_SERVERS_MAX+1; p++){
        if(pipe(fd[p]) == -1){
            write_to_log_console("Error creating unnamed pipe\n");
            exit(0);
        }
        write_to_log_console("unnamed pipe created\n");
    }
}

void auth_engine(int n_pipe){
    int read_flag;
    char command[BUFFER_SIZE];
    char log_text[BUFFER_SIZE];
    for(int j = 0;j<config1.AUTH_SERVERS_MAX;j++){
            if(n_pipe != j){
                close(fd[j][1]);
                close(fd[j][0]);
            }
        }
    close(fd[n_pipe][1]);
    while(1){
        if((read_flag = read(fd[n_pipe][0],command,BUFFER_SIZE)) == -1){
            write_to_log_console("Erro a ler da unnamed pipe\n");
            exit(0);
        }
        //usleep(config1.AUTH_PROC_TIME * 1000);
        if(read_flag > 0){
            sem_wait(sem_an);
            process_command(command);
            *(ptr + n_pipe) = 1;
            sem_post(sem_an);
            snprintf(log_text, BUFFER_SIZE, "AUTHORIZATION_ENGINE %d:VIDEO AUTHORIZATION REQUEST (ID = %d) PROCESSING COMPLETED\n", n_pipe, atoi(strtok(command, "#")));
            write_to_log_console(log_text);
        }
    }
}

int cont_hast(char command[]){
    int cont=0;
    for(int i=0;i<(int)strlen(command);i++){
        if(command[i]=='#'){
            cont++;
        }
    }
    return cont;
}


void create_shared_memory(){
    if ((shmid = shmget(KEY+10, sizeof(SHARED_MEM), IPC_CREAT | 0777)) == -1)
    {
        write_to_log_console("Error creating shared memory 1\n");
        exit(-1);
    }
    memory = (SHARED_MEM*)shmat(shmid, NULL,0);
    if ((shmid2 = shmget(KEY+20, sizeof(USER_TO_SHM)*config1.MOBILE_USERS, IPC_CREAT | 0777)) == -1)
    {
        write_to_log_console("Error creating shared memory 2\n");
        exit(-1);
    }
    memory->USERS_INFO = (USER_TO_SHM*)shmat(shmid2, NULL,0);
    if ((shmid3 = shmget(KEY+90, sizeof(int)*(config1.AUTH_SERVERS_MAX+1), IPC_CREAT | 0777)) == -1)
    {
        write_to_log_console("Error creating shared memory\n");
        exit(-1);
    }
    ptr = (int*)shmat(shmid3, NULL,0);
    pthread_mutexattr_init(&attrmutex);
    pthread_mutexattr_setpshared(&attrmutex, PTHREAD_PROCESS_SHARED);

    pthread_condattr_init(&attrcondv);
    pthread_condattr_setpshared(&attrcondv, PTHREAD_PROCESS_SHARED);
    
    pthread_mutex_init(&memory->mutex, &attrmutex);
    pthread_cond_init(&memory->monitor_cond, &attrcondv);

    for(int i=0;i<config1.AUTH_SERVERS_MAX+1;i++){
        *(ptr+i)=1;
    }

    for(int i = 0; i < config1.MOBILE_USERS; i++) {
        memory->USERS_INFO[i].USER_ID = 0;
        memory->USERS_INFO[i].USER_INITIAL_PLAFON = 0;
        memory->USERS_INFO[i].USER_CURRENT_PLAFON = 0;
        memory->USERS_INFO[i].flag = 0;
    }

    for(int i = 0; i < 3; i++) {
        memory->stats[i].AUTH_REQUEST_NUM = 0;
        memory->stats[i].TOTAL_DATA = 0;
    }

    write_to_log_console("ATTACH SUCESSFULL!\n");
    write_to_log_console("SHARED MEMORY CREATED!\n");
}


void process_command(char command[]){
    pthread_mutex_lock(&memory->mutex);
    if(cont_hast(command)==1){
        char *id=strtok(command, "#");
        char *plafon=strtok(NULL, "#");
        if(strcmp(plafon, "data_stats")==0){
            snprintf(command,BUFFER_SIZE,"Service       Total Data      Auth Reqs\nVIDEO             %d             %d\nMUSIC             %d             %d\nSOCIAL            %d             %d\n",memory->stats[0].TOTAL_DATA,memory->stats[0].AUTH_REQUEST_NUM,memory->stats[1].TOTAL_DATA,memory->stats[1].AUTH_REQUEST_NUM,memory->stats[2].TOTAL_DATA,memory->stats[2].AUTH_REQUEST_NUM);
            send_to_message_queue(command,5);
        }
        else if(strcmp(plafon, "resetstats")==0){
            for(int i=0;i<3;i++){
                memory->stats[i].TOTAL_DATA=0;
                memory->stats[i].AUTH_REQUEST_NUM=0;
            }
        }
        for(int i=0;i<config1.MOBILE_USERS;i++){
            if(memory->USERS_INFO[i].USER_ID==0){
                memory->USERS_INFO[i].USER_ID=atoi(id);
                memory->USERS_INFO[i].USER_INITIAL_PLAFON=atoi(plafon);
                memory->USERS_INFO[i].USER_CURRENT_PLAFON=atoi(plafon);
                break;
            }
        }
    }else if(cont_hast(command)==2){
        if(strstr(command, "#VIDEO#")!=NULL){
            char *id=strtok(command, "#VIDEO#");
            char *plafon_request=strtok(NULL, "#VIDEO#");
            for(int i=0;i<config1.MOBILE_USERS;i++){
                if(atoi(id) == memory->USERS_INFO[i].USER_ID){
                    if(memory->USERS_INFO[i].USER_CURRENT_PLAFON >= atoi(plafon_request)){
                        memory->USERS_INFO[i].USER_CURRENT_PLAFON -= atoi(plafon_request);
                        memory->stats[0].TOTAL_DATA += atoi(plafon_request);
                        memory->stats[0].AUTH_REQUEST_NUM  += 1;
                        pthread_cond_signal(&memory->monitor_cond);
                    }
                    break;
                }
            }
        }
        else if(strstr(command, "#MUSIC#")!=NULL){
            char *id=strtok(command, "#MUSIC#");
            char *plafon_request=strtok(NULL, "#MUSIC#");
            for(int i=0;i<config1.MOBILE_USERS;i++){
                if(atoi(id) == memory->USERS_INFO[i].USER_ID){
                    if(memory->USERS_INFO[i].USER_CURRENT_PLAFON >= atoi(plafon_request)){
                        memory->USERS_INFO[i].USER_CURRENT_PLAFON-= atoi(plafon_request);
                        memory->stats[1].TOTAL_DATA += atoi(plafon_request);
                        memory->stats[1].AUTH_REQUEST_NUM  +=1;
                        pthread_cond_signal(&memory->monitor_cond);
                    }
                    break;
                }
            }    
        }
        else if(strstr(command, "#SOCIAL#")!=NULL){
            char *id=strtok(command, "#SOCIAL#");
            char *plafon_request=strtok(NULL, "#SOCIAL#");
            for(int i=0;i<config1.MOBILE_USERS;i++){
                if(atoi(id) == memory->USERS_INFO[i].USER_ID){
                    if(memory->USERS_INFO[i].USER_CURRENT_PLAFON >= atoi(plafon_request)){
                        memory->USERS_INFO[i].USER_CURRENT_PLAFON-= atoi(plafon_request);
                        memory->stats[2].TOTAL_DATA += atoi(plafon_request);
                        memory->stats[2].AUTH_REQUEST_NUM  +=1;
                        pthread_cond_signal(&memory->monitor_cond);
                    }
                    break;
                }
            }
        }
    }
    pthread_mutex_unlock(&memory->mutex);
}

void *send_to_back_ofiice(){
    char command[BUFFER_SIZE];
    while(1){
        pthread_mutex_lock(&sh_mutex);
        snprintf(command,BUFFER_SIZE,"Service       Total Data      Auth Reqs\nVIDEO             %d             %d\nMUSIC             %d             %d\nSOCIAL            %d             %d\n",memory->stats[0].TOTAL_DATA,memory->stats[0].AUTH_REQUEST_NUM,memory->stats[1].TOTAL_DATA,memory->stats[1].AUTH_REQUEST_NUM,memory->stats[2].TOTAL_DATA,memory->stats[2].AUTH_REQUEST_NUM);
        send_to_message_queue(command,5);
        pthread_mutex_unlock(&sh_mutex);
        sleep(30);
    }
}


void *alert_user(){ 
    char alert[BUFFER_SIZE];
    while(1){
        pthread_mutex_lock(&memory->mutex);
        pthread_cond_wait(&memory->monitor_cond, &memory->mutex);
        for(int i = 0; i < config1.MOBILE_USERS;i++){
            if(memory->USERS_INFO[i].USER_ID != 0){
                float percentage_used = 1.0 - ((float)memory->USERS_INFO[i].USER_CURRENT_PLAFON / memory->USERS_INFO[i].USER_INITIAL_PLAFON);
                if(percentage_used >= 0.8 && percentage_used <0.9 && memory->USERS_INFO[i].flag == 0){
                    snprintf(alert,BUFFER_SIZE, "ALERT 80 percent (USER %d) TRIGGERED\n",i+1);
                    send_to_message_queue("80",memory->USERS_INFO[i].USER_ID);
                    write_to_log_console(alert);
                    memory->USERS_INFO[i].flag = 80;
                }
                else if(percentage_used >= 0.9 && percentage_used <1 && (memory->USERS_INFO[i].flag == 80 ||memory->USERS_INFO[i].flag==0)){
                    snprintf(alert,BUFFER_SIZE, "ALERT 90 percent (USER %d) TRIGGERED\n",i+1);
                    send_to_message_queue("90",memory->USERS_INFO[i].USER_ID);
                    write_to_log_console(alert);
                    memory->USERS_INFO[i].flag = 90;
                }
                else if(percentage_used == 1 && (memory->USERS_INFO[i].flag == 90 || memory->USERS_INFO[i].flag==80 ||memory->USERS_INFO[i].flag==0)){
                    snprintf(alert,BUFFER_SIZE, "ALERT 100 percent (USER %d) TRIGGERED\n",i+1);
                    send_to_message_queue("100",memory->USERS_INFO[i].USER_ID);
                    write_to_log_console(alert);
                    memory->USERS_INFO[i].flag = 100;
                }
            }
        }
        pthread_mutex_unlock(&memory->mutex);
    }
}


void create_msg_queue() {
    key_t key = ftok("/tmp", MSG_KEY);
    if (key == -1) {
        perror("ftok");
        exit(EXIT_FAILURE);
    }

    msg_queue_id = msgget(key, IPC_CREAT | 0666);
    if (msg_queue_id == -1) {
        perror("msgget");
        exit(EXIT_FAILURE);
    }
}

void send_to_message_queue(char command[], int id) {
    message_sent.mtype = id;
    strcpy(message_sent.alerta,command);
    if(msgsnd(msg_queue_id, &message_sent, sizeof(msg), 0) == -1) {
        perror("msgsnd");
        exit(EXIT_FAILURE);
    }
}
void create_extra_engine(){
    pid_extra_engine = fork();
    if(pid_extra_engine < 0){
        write_to_log_console("Error while creating process autorization engine\n");
        exit(-1);
    }
    else if(pid_extra_engine == 0){
        write_to_log_console("AUTHORIZATION ENGINE EXTRA CREATED\n");
        auth_engine(config1.AUTH_SERVERS_MAX + 1);
    }
}

void kill_extra_engine(){
    if (kill(pid_extra_engine, SIGTERM) == 0) {
        write_to_log_console("EXTRA ENGINE CLOSED AND KILLED\n");
    } else {
        write_to_log_console("Erro ao encerrar o processo extra engine");
        exit(-1);
    }
}


// Implementação da função de limpeza de recursos
void sigint_handler(int signum) {
    (void)signum;
    write_to_log_console("SIGINT received, cleaning up resources...\n");
    // Bloquear mutexes
    pthread_mutex_lock(&queue_mutex);
    pthread_mutex_lock(&memory->mutex);
    // Clean up named pipes
    unlink(PIPE_NAME);
    unlink(PIPE_NAME2);
    while(espera_auth()){
    }
    write_to_log_console("5G_AUTH_PLATFORM SIMULATOR WAITING FOR LAST TASKS TO FINISH\n");
    while(!is_empty(&video_queue)){
        QUEUE *current = video_queue;
        char buffer[BUFFER_SIZE];
        snprintf(buffer, BUFFER_SIZE, "Mensagem %s retirada da video queue\n", current->buffer);
        write_to_log_console(buffer);
        remove_from_queue(&video_queue);
        free(current);
    }
    while(!is_empty(&others_queue)){
        QUEUE *current = others_queue;
        char buffer[BUFFER_SIZE];
        snprintf(buffer, BUFFER_SIZE, "Mensagem %s retirada da others queue\n", current->buffer);
        write_to_log_console(buffer);
        remove_from_queue(&others_queue);
        free(current);
    }
    //Clean up semaphores
    sem_close(acess_queue);
    sem_unlink("acess_queue");
    sem_close(sem_an);
    sem_unlink("sem_an");

    if (memory != NULL) {
        if (memory->USERS_INFO != NULL) {
            shmdt(memory->USERS_INFO);
        }
    }
    if (shmid != -1) {
        shmctl(shmid, IPC_RMID, NULL);
    }
    if (memory->USERS_INFO != NULL) {
        shmdt(memory->USERS_INFO);
    }
    if (shmid2 != -1) {
        shmctl(shmid2, IPC_RMID, NULL);
    }
    if (ptr != NULL) {
        shmdt(ptr);
    }
    if (shmid3 != -1) {
        shmctl(shmid3, IPC_RMID, NULL);
    }

    // Clean up message queue
    if (msg_queue_id != -1) {
        msgctl(msg_queue_id, IPC_RMID, NULL);
    }

    // Terminate extra engine if running
    if (pid_extra_engine > 0) {
        kill_extra_engine();
    }

    // Desbloquear mutexes
    pthread_mutex_unlock(&memory->mutex);
    pthread_mutex_unlock(&queue_mutex);

    write_to_log_console("5G_AUTH_PLATFORM SIMULATOR CLOSING\n");
    exit(0);
}

int espera_auth(){
    int count = 0;
    for(int i = 0; i < config1.AUTH_SERVERS_MAX; i++){
        if(*(ptr+i) == 1){
            count++;
        }
    }
    if(count == config1.AUTH_SERVERS_MAX){
        return 0;
    }
    else{
        return 1;
    }
}
