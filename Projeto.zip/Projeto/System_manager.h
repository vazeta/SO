// CODED BY:
// André Teixeira - 2022231134
// João Vaz - 2022231087

#ifndef HEADER_H
#define HEADER_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <wait.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <semaphore.h> 
#include <time.h>
#include <pthread.h>
#include <sys/wait.h>
#include "Struct.h"
#include "errno.h"
#include "sys/select.h"
#include <signal.h>
#include <signal.h>
#define PIPE_NAME "/tmp/USER_PIPE"
#define PIPE_NAME2 "/tmp/BACK_OFFICE_PIPE"
#define BUFFER_SIZE 1024
#define MSG_KEY 1234
config config1;
char buffer[BUFFER_SIZE];
char buffer2[BUFFER_SIZE];
int number_of_chars=0;
QUEUE *video_queue=NULL;
QUEUE *others_queue=NULL;
sem_t *acess_queue;
sem_t *sem_an;
int *ptr;
int fd[100][2];
int cont_video=0;
int cont_others=0;
int shmid,shmid2,shmid3;
SHARED_MEM *memory;
key_t KEY =101;
int msg_queue_id;
pthread_mutex_t sh_mutex=PTHREAD_MUTEX_INITIALIZER;
pid_t pid_extra_engine;
pthread_cond_t queue_condition = PTHREAD_COND_INITIALIZER;
pthread_mutex_t queue_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutexattr_t attrmutex;
pthread_condattr_t attrcondv;
pthread_t receiver, sender;
msg message_sent;

void write_to_log_console(char *text );
void create_auth_request_manager();
void create_monitor_engine();
void* receiver_func();
void* sender_func();
void create_shared_memory();
void createNamedPipe();
void insert_others_queue(QUEUE** others_queue,char * buffer);
void insert_video_queue(QUEUE** video_queue,char * buffer);
void remove_from_queue(QUEUE** queue);
void init_sem_queue();
int is_empty(QUEUE** queue);
void create_auth_eng();
void create_unamed_pipes();
int pick_pipe(int num_engines, int n_pipe);
void send_to_unnamed_pipe(int n_pipe, char command[]);
void auth_engine(int i);
void process_command(char *command);
void create_msg_queue();
void send_to_message_queue(char command[], int id);
void *alert_user();
void *send_to_back_ofiice();
void sigint_handler();
void create_extra_engine();
void kill_extra_engine();
void send_to_message_queue2(char command[], int id);
void sigint_handler(int signum);
int espera_auth();
#endif